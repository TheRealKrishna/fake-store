(() => {
var exports = {};
exports.id = 716;
exports.ids = [716];
exports.modules = {

/***/ 8038:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react");

/***/ }),

/***/ 8704:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-dom/server-rendering-stub");

/***/ }),

/***/ 7897:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-server-dom-webpack/client");

/***/ }),

/***/ 6786:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react/jsx-runtime");

/***/ }),

/***/ 5868:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/app-render/app-render");

/***/ }),

/***/ 1844:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/app-render/get-segment-param");

/***/ }),

/***/ 6624:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/future/helpers/interception-routes");

/***/ }),

/***/ 5281:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/future/route-modules/route-module");

/***/ }),

/***/ 7085:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/app-router-context");

/***/ }),

/***/ 1830:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/get-img-props");

/***/ }),

/***/ 199:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/hash");

/***/ }),

/***/ 6864:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head");

/***/ }),

/***/ 9569:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/hooks-client-context");

/***/ }),

/***/ 2210:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config");

/***/ }),

/***/ 5359:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config-context");

/***/ }),

/***/ 7160:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context");

/***/ }),

/***/ 893:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix");

/***/ }),

/***/ 2336:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-url");

/***/ }),

/***/ 7887:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/handle-smooth-scroll");

/***/ }),

/***/ 8735:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-bot");

/***/ }),

/***/ 120:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-local-url");

/***/ }),

/***/ 8231:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-path");

/***/ }),

/***/ 4614:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/path-has-prefix");

/***/ }),

/***/ 3750:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash");

/***/ }),

/***/ 982:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/resolve-href");

/***/ }),

/***/ 9618:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/server-inserted-html");

/***/ }),

/***/ 8423:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils");

/***/ }),

/***/ 8658:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils/warn-once");

/***/ }),

/***/ 1017:
/***/ ((module) => {

"use strict";
module.exports = require("path");

/***/ }),

/***/ 7310:
/***/ ((module) => {

"use strict";
module.exports = require("url");

/***/ }),

/***/ 1657:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   GlobalError: () => (/* reexport default from dynamic */ next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_2___default.a),
/* harmony export */   __next_app__: () => (/* binding */ __next_app__),
/* harmony export */   originalPathname: () => (/* binding */ originalPathname),
/* harmony export */   pages: () => (/* binding */ pages),
/* harmony export */   routeModule: () => (/* binding */ routeModule),
/* harmony export */   tree: () => (/* binding */ tree)
/* harmony export */ });
/* harmony import */ var next_dist_server_future_route_modules_app_page_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(7262);
/* harmony import */ var next_dist_server_future_route_modules_app_page_module__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_future_route_modules_app_page_module__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_dist_server_future_route_kind__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9513);
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1823);
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2502);
/* harmony import */ var next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_3__);
/* harmony reexport (unknown) */ var __WEBPACK_REEXPORT_OBJECT__ = {};
/* harmony reexport (unknown) */ for(const __WEBPACK_IMPORT_KEY__ in next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_3__) if(["default","tree","pages","GlobalError","originalPathname","__next_app__","routeModule"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) __WEBPACK_REEXPORT_OBJECT__[__WEBPACK_IMPORT_KEY__] = () => next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_3__[__WEBPACK_IMPORT_KEY__]
/* harmony reexport (unknown) */ __webpack_require__.d(__webpack_exports__, __WEBPACK_REEXPORT_OBJECT__);
// @ts-ignore this need to be imported from next/dist to be external


const AppPageRouteModule = next_dist_server_future_route_modules_app_page_module__WEBPACK_IMPORTED_MODULE_0__.AppPageRouteModule;
// We inject the tree and pages here so that we can use them in the route
// module.
const tree = {
        children: [
        '',
        {
        children: [
        'auth',
        {
        children: [
        'login',
        {
        children: ['__PAGE__', {}, {
          page: [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 8531)), "E:\\Study Notes\\Visual Studio Projects\\Learning Next.js\\fake-store\\src\\app\\auth\\login\\page.js"],
          
        }]
      },
        {
        
        
      }
      ]
      },
        {
        
        metadata: {
    icon: [(async (props) => (await Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 3881))).default(props))],
    apple: [],
    openGraph: [],
    twitter: [],
    manifest: undefined
  }
      }
      ]
      },
        {
        'layout': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 1159)), "E:\\Study Notes\\Visual Studio Projects\\Learning Next.js\\fake-store\\src\\app\\layout.js"],
'not-found': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 5493, 23)), "next/dist/client/components/not-found-error"],
        metadata: {
    icon: [(async (props) => (await Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 3881))).default(props))],
    apple: [],
    openGraph: [],
    twitter: [],
    manifest: undefined
  }
      }
      ]
      }.children;
const pages = ["E:\\Study Notes\\Visual Studio Projects\\Learning Next.js\\fake-store\\src\\app\\auth\\login\\page.js"];

// @ts-expect-error - replaced by webpack/turbopack loader

const __next_app_require__ = __webpack_require__
const __next_app_load_chunk__ = () => Promise.resolve()
const originalPathname = "/auth/login/page";
const __next_app__ = {
    require: __next_app_require__,
    loadChunk: __next_app_load_chunk__
};

// Create and export the route module that will be consumed.
const routeModule = new AppPageRouteModule({
    definition: {
        kind: next_dist_server_future_route_kind__WEBPACK_IMPORTED_MODULE_1__.RouteKind.APP_PAGE,
        page: "/auth/login/page",
        pathname: "/auth/login",
        // The following aren't used in production.
        bundlePath: "",
        filename: "",
        appPaths: []
    },
    userland: {
        loaderTree: tree
    }
});

//# sourceMappingURL=app-page.js.map

/***/ }),

/***/ 2580:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 5341))

/***/ }),

/***/ 5341:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ Page)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(6786);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(2451);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
// EXTERNAL MODULE: ./src/app/auth/login/page.module.css
var page_module = __webpack_require__(6050);
var page_module_default = /*#__PURE__*/__webpack_require__.n(page_module);
;// CONCATENATED MODULE: ./src/app/auth/login/login.svg
/* harmony default export */ const login = ({"src":"/_next/static/media/login.96da1301.svg","height":300,"width":300,"blurWidth":0,"blurHeight":0});
// EXTERNAL MODULE: ./node_modules/@fortawesome/fontawesome-free/css/all.min.css
var all_min = __webpack_require__(7100);
// EXTERNAL MODULE: external "next/dist/compiled/react"
var react_ = __webpack_require__(8038);
// EXTERNAL MODULE: ./node_modules/react-hot-toast/dist/index.mjs + 1 modules
var dist = __webpack_require__(345);
// EXTERNAL MODULE: ./node_modules/next/navigation.js
var navigation = __webpack_require__(7114);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1440);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
// EXTERNAL MODULE: ./src/app/components/loader.js
var loader = __webpack_require__(815);
;// CONCATENATED MODULE: ./src/app/auth/login/page.js
/* __next_internal_client_entry_do_not_use__ default auto */ 









function Page() {
    const router = (0,navigation.useRouter)();
    const [credentials, setCredentials] = (0,react_.useState)({
        email: "",
        password: ""
    });
    const [confirmPasswordType, setConfirmPasswordType] = (0,react_.useState)("password");
    const [passwordRevealIcon, setPasswordRevealIcon] = (0,react_.useState)("fa-eye-slash");
    const confirmPasswordElement = (0,react_.useRef)();
    const signUpHandler = (e)=>{
        e.preventDefault();
        dist["default"].promise(new Promise(async (resolve, reject)=>{
            const response = await fetch("/api/auth/login", {
                headers: {
                    "Content-Type": "application/json"
                },
                method: "POST",
                body: JSON.stringify({
                    email: credentials.email,
                    password: credentials.password
                })
            });
            const json = await response.json();
            if (json.success) {
                localStorage.setItem("auth-token", json.token);
                resolve();
                router.back();
            } else {
                reject(json.error);
            }
        }), {
            loading: "Logging In..",
            success: /*#__PURE__*/ jsx_runtime_.jsx("b", {
                children: "Logged In Succesfully!"
            }),
            error: (err)=>/*#__PURE__*/ jsx_runtime_.jsx("b", {
                    children: err
                })
        });
    };
    const revealPassword = ()=>{
        if (confirmPasswordType === "password") {
            setConfirmPasswordType("text");
            setPasswordRevealIcon("fa-eye");
        } else {
            setConfirmPasswordType("password");
            setPasswordRevealIcon("fa-eye-slash");
        }
    };
    const handleInputChange = async (e)=>{
        setCredentials({
            ...credentials,
            [e.target.name]: e.target.value
        });
        if (e.target.name === "password" || e.target.name === "confirmPassword") {
            if (e.target.name === "confirmPassword" && e.target.value !== credentials.password) {
                confirmPasswordElement.current?.setCustomValidity("Passwords Do Not Match");
            } else {
                confirmPasswordElement.current?.setCustomValidity("");
            }
        }
    };
    if (localStorage.getItem("auth-token")) {
        router.push("/");
        return /*#__PURE__*/ jsx_runtime_.jsx(loader/* default */.Z, {});
    } else {
        return /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
            children: /*#__PURE__*/ jsx_runtime_.jsx("form", {
                onSubmit: signUpHandler,
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "container mt-5 d-flex",
                    style: {
                        height: "500px",
                        width: "1000px"
                    },
                    children: [
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: `container bg-warning ${(page_module_default()).yellowBox}`,
                            style: {
                                flex: "1",
                                borderTop: "1px solid black"
                            },
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                                    style: {
                                        fontFamily: "revert-layer",
                                        fontWeight: "bold",
                                        padding: "5px 30%",
                                        marginTop: "35px"
                                    },
                                    children: "Log In"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("h6", {
                                    style: {
                                        color: "grey"
                                    },
                                    children: "Get access to your Orders, Wishlist and Recommendations"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                    src: login,
                                    style: {
                                        position: "absolute",
                                        bottom: "100px"
                                    },
                                    alt: "SignUp Image"
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: `container bg-light ${(page_module_default()).lightBox}`,
                            style: {
                                flex: "2"
                            },
                            children: [
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: (page_module_default()).inputs,
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                            className: "fa-solid fa-envelope",
                                            style: {
                                                color: "#ffc107",
                                                marginTop: "7px"
                                            }
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                            required: true,
                                            type: "email",
                                            onChange: handleInputChange,
                                            name: "email",
                                            value: credentials.email,
                                            className: "bg-light",
                                            placeholder: "email"
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: (page_module_default()).inputs,
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                            className: "fa-solid fa-lock",
                                            style: {
                                                color: "#ffc107",
                                                marginTop: "7px"
                                            }
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                            required: true,
                                            type: confirmPasswordType,
                                            onChange: handleInputChange,
                                            name: "password",
                                            value: credentials.password,
                                            minLength: 8,
                                            className: "bg-light",
                                            placeholder: "password"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                            className: `fa-solid ${passwordRevealIcon}`,
                                            onClick: revealPassword,
                                            style: {
                                                color: "#000000",
                                                position: "absolute",
                                                right: "360px",
                                                marginTop: "7px",
                                                cursor: "pointer"
                                            }
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    style: {
                                        marginTop: "20px",
                                        marginBottom: "60px"
                                    },
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                        style: {
                                            position: "absolute",
                                            left: "720px"
                                        },
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                            style: {
                                                textDecoration: "none"
                                            },
                                            href: "/auth/forgot-password",
                                            target: "_blank",
                                            children: "Forgot Password"
                                        })
                                    })
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: (page_module_default()).inputs,
                                    style: {
                                        margin: "0px"
                                    },
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                        className: "btn btn-warning",
                                        style: {
                                            marginLeft: "30px"
                                        },
                                        type: "submit",
                                        children: "Log In"
                                    })
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    style: {
                                        marginTop: "90px"
                                    },
                                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                                        style: {
                                            position: "absolute",
                                            left: "720px"
                                        },
                                        children: [
                                            "Not a member yet? ",
                                            /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                style: {
                                                    textDecoration: "none"
                                                },
                                                href: "/auth/signup",
                                                children: "Create Account"
                                            })
                                        ]
                                    })
                                })
                            ]
                        })
                    ]
                })
            })
        });
    }
}


/***/ }),

/***/ 6050:
/***/ ((module) => {

// Exports
module.exports = {
	"yellowBox": "page_yellowBox__A_7n8",
	"lightBox": "page_lightBox__hOvoX",
	"inputs": "page_inputs__0AZCS"
};


/***/ }),

/***/ 8531:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   $$typeof: () => (/* binding */ $$typeof),
/* harmony export */   __esModule: () => (/* binding */ __esModule),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var next_dist_build_webpack_loaders_next_flight_loader_module_proxy__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1363);

const proxy = (0,next_dist_build_webpack_loaders_next_flight_loader_module_proxy__WEBPACK_IMPORTED_MODULE_0__.createProxy)(String.raw`E:\Study Notes\Visual Studio Projects\Learning Next.js\fake-store\src\app\auth\login\page.js`)

// Accessing the __esModule property and exporting $$typeof are required here.
// The __esModule getter forces the proxy target to create the default export
// and the $$typeof value is for rendering logic to determine if the module
// is a client boundary.
const { __esModule, $$typeof } = proxy;
const __default__ = proxy.default;


/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (__default__);

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [587,630,451,232], () => (__webpack_exec__(1657)));
module.exports = __webpack_exports__;

})();