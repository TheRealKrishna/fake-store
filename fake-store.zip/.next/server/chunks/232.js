exports.id = 232;
exports.ids = [232];
exports.modules = {

/***/ 7331:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 1232, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 2987, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 831, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 6926, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 4282, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 6505, 23))

/***/ }),

/***/ 4303:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 1832));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 345))

/***/ }),

/***/ 815:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (/* binding */ Loader)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6786);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _loader_module_css__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(8125);
/* harmony import */ var _loader_module_css__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_loader_module_css__WEBPACK_IMPORTED_MODULE_1__);
/* __next_internal_client_entry_do_not_use__ default auto */ 

function Loader() {
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
        className: (_loader_module_css__WEBPACK_IMPORTED_MODULE_1___default().loader),
        style: {
            marginTop: "250px"
        }
    });
}


/***/ }),

/***/ 1832:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ Navbar)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6786);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _navbar_module_css__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(6435);
/* harmony import */ var _navbar_module_css__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(_navbar_module_css__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _fortawesome_fontawesome_free_css_all_min_css__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(7100);
/* harmony import */ var _fortawesome_fontawesome_free_css_all_min_css__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_fortawesome_fontawesome_free_css_all_min_css__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1440);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_navigation__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(7114);
/* harmony import */ var next_navigation__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_navigation__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(8038);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var react_hot_toast__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(345);
/* __next_internal_client_entry_do_not_use__ default auto */ 








function Navbar(params) {
    const pathname = (0,next_navigation__WEBPACK_IMPORTED_MODULE_3__.usePathname)();
    const router = (0,next_navigation__WEBPACK_IMPORTED_MODULE_3__.useRouter)();
    const searchParams = (0,next_navigation__WEBPACK_IMPORTED_MODULE_3__.useSearchParams)();
    const [profileMenu, setProfileMenu] = (0,react__WEBPACK_IMPORTED_MODULE_4__.useState)(false);
    const [searchKeyword, setSearchKeyword] = (0,react__WEBPACK_IMPORTED_MODULE_4__.useState)(searchParams.get("search") ? searchParams.get("search") : "");
    const toggleProfileMenu = ()=>{
        if (localStorage.getItem("auth-token")) {
            setProfileMenu(!profileMenu);
        } else {
            router.push("/member/profile");
        }
    };
    const searchChangeHandler = (e)=>{
        setSearchKeyword(e.target.value);
    };
    const handleLogout = ()=>{
        react_hot_toast__WEBPACK_IMPORTED_MODULE_5__.toast.promise(new Promise(async (resolve, reject)=>{
            localStorage.removeItem("auth-token");
            if (localStorage.getItem("auth-token")) {
                reject("An Error Occured!");
            } else {
                setProfileMenu(!profileMenu);
                router.push("/");
                resolve();
            }
        }), {
            loading: "Logging Out...",
            success: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("b", {
                children: "Logged Out Succesfully"
            }),
            error: (error)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("b", {
                    children: error
                })
        }, {
            iconTheme: {
                primary: "red",
                secondary: "#FFFAEE"
            }
        });
    };
    (0,react__WEBPACK_IMPORTED_MODULE_4__.useEffect)(()=>{
        setProfileMenu(false);
    }, [
        searchParams,
        router.pathname
    ]);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("nav", {
                className: (_navbar_module_css__WEBPACK_IMPORTED_MODULE_6___default().navbar),
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: (_navbar_module_css__WEBPACK_IMPORTED_MODULE_6___default().pass),
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: (_navbar_module_css__WEBPACK_IMPORTED_MODULE_6___default().opp),
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
                                href: "/",
                                children: "Fake Store"
                            })
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("ul", {
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                    className: `${(_navbar_module_css__WEBPACK_IMPORTED_MODULE_6___default().navLi)} ${pathname === "/" ? (_navbar_module_css__WEBPACK_IMPORTED_MODULE_6___default().navLiActive) : ""}`,
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
                                        href: "/",
                                        children: "Home"
                                    })
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                    className: `${(_navbar_module_css__WEBPACK_IMPORTED_MODULE_6___default().navLi)} ${pathname === "/category/electronics" ? (_navbar_module_css__WEBPACK_IMPORTED_MODULE_6___default().navLiActive) : ""}`,
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
                                        href: "/category/electronics",
                                        children: "Electronics"
                                    })
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                    className: `${(_navbar_module_css__WEBPACK_IMPORTED_MODULE_6___default().navLi)} ${pathname === "/category/jewelery" ? (_navbar_module_css__WEBPACK_IMPORTED_MODULE_6___default().navLiActive) : ""}`,
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
                                        href: "/category/jewelery",
                                        children: "Jewelery"
                                    })
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                    className: `${(_navbar_module_css__WEBPACK_IMPORTED_MODULE_6___default().navLi)} ${pathname === "/category/men's%20clothing" ? (_navbar_module_css__WEBPACK_IMPORTED_MODULE_6___default().navLiActive) : ""}`,
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
                                        href: "/category/men's clothing",
                                        children: "Men's clothing"
                                    })
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                    className: `${(_navbar_module_css__WEBPACK_IMPORTED_MODULE_6___default().navLi)} ${pathname === "/category/women's%20clothing" ? (_navbar_module_css__WEBPACK_IMPORTED_MODULE_6___default().navLiActive) : ""}`,
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
                                        href: "/category/women's clothing",
                                        children: "Women's clothing"
                                    })
                                })
                            ]
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("form", {
                                onSubmit: (e)=>{
                                    e.preventDefault();
                                    router.push(`../?search=${searchKeyword}`);
                                },
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                        className: (_navbar_module_css__WEBPACK_IMPORTED_MODULE_6___default().navInput),
                                        type: "text",
                                        id: "search",
                                        name: "search",
                                        value: searchKeyword,
                                        onChange: searchChangeHandler,
                                        placeholder: "Search..."
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                        className: (_navbar_module_css__WEBPACK_IMPORTED_MODULE_6___default().navButton),
                                        type: "submit",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                                            className: "fa-solid fa-magnifying-glass",
                                            style: {
                                                color: "black"
                                            }
                                        })
                                    })
                                ]
                            })
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            style: {
                                marginRight: "30px"
                            },
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
                                    href: "/member/cart",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                                        className: (_navbar_module_css__WEBPACK_IMPORTED_MODULE_6___default().navIcon) + " fas fa-cart-shopping"
                                    })
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                                    onClick: toggleProfileMenu,
                                    className: (_navbar_module_css__WEBPACK_IMPORTED_MODULE_6___default().navIcon) + " fas fa-circle-user"
                                })
                            ]
                        })
                    ]
                })
            }),
            profileMenu && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                        className: `fas fa-caret-up ${(_navbar_module_css__WEBPACK_IMPORTED_MODULE_6___default().profileMenuTip)}`
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: (_navbar_module_css__WEBPACK_IMPORTED_MODULE_6___default().profileMenu),
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("ul", {
                            style: {
                                margin: "0px",
                                paddingLeft: "0px"
                            },
                            children: [
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("li", {
                                    style: {
                                        listStyle: "none",
                                        marginBottom: "13px"
                                    },
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                                            className: "fa-solid fa-user",
                                            style: {
                                                color: "orange",
                                                marginRight: "5px"
                                            }
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
                                            onClick: ()=>setProfileMenu(false),
                                            className: (_navbar_module_css__WEBPACK_IMPORTED_MODULE_6___default().profileMenuItem),
                                            href: "/member/profile",
                                            children: "Profile"
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("li", {
                                    style: {
                                        listStyle: "none",
                                        marginBottom: "13px"
                                    },
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                                            className: "fa-solid fa-address-book",
                                            style: {
                                                color: "orange",
                                                marginRight: "5px"
                                            }
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
                                            onClick: ()=>setProfileMenu(false),
                                            className: (_navbar_module_css__WEBPACK_IMPORTED_MODULE_6___default().profileMenuItem),
                                            href: "/member/address ",
                                            children: "Address"
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("li", {
                                    style: {
                                        listStyle: "none",
                                        marginBottom: "13px"
                                    },
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                                            className: "fa-solid fa-box",
                                            style: {
                                                color: "orange",
                                                marginRight: "5px"
                                            }
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
                                            onClick: ()=>setProfileMenu(false),
                                            className: (_navbar_module_css__WEBPACK_IMPORTED_MODULE_6___default().profileMenuItem),
                                            href: "/member/orders",
                                            children: "Orders"
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("li", {
                                    style: {
                                        listStyle: "none",
                                        marginBottom: "13px"
                                    },
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                                            className: "fa-solid fa-heart",
                                            style: {
                                                color: "orange",
                                                marginRight: "5px"
                                            }
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
                                            onClick: ()=>setProfileMenu(false),
                                            className: (_navbar_module_css__WEBPACK_IMPORTED_MODULE_6___default().profileMenuItem),
                                            href: "/member/wishlist",
                                            children: "Wish List"
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("hr", {}),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("li", {
                                    style: {
                                        listStyle: "none",
                                        marginBottom: "5px"
                                    },
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                                            className: "fa-solid fa-power-off",
                                            style: {
                                                color: "red",
                                                marginRight: "5px"
                                            }
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                            className: (_navbar_module_css__WEBPACK_IMPORTED_MODULE_6___default().profileMenuItem),
                                            style: {
                                                cursor: "pointer"
                                            },
                                            onClick: handleLogout,
                                            children: "Logout"
                                        })
                                    ]
                                })
                            ]
                        })
                    })
                ]
            })
        ]
    });
}


/***/ }),

/***/ 8125:
/***/ ((module) => {

// Exports
module.exports = {
	"loader": "loader_loader__7XEVx",
	"animloader": "loader_animloader__93aPY"
};


/***/ }),

/***/ 6435:
/***/ ((module) => {

// Exports
module.exports = {
	"navbar": "navbar_navbar__BJuG4",
	"pass": "navbar_pass___mi9N",
	"opp": "navbar_opp__bLKdW",
	"navLi": "navbar_navLi___EPrp",
	"navLiActive": "navbar_navLiActive___Oznb",
	"navButton": "navbar_navButton__h9oCx",
	"navLoginButton": "navbar_navLoginButton__rHsEQ",
	"navInput": "navbar_navInput__U2hHg",
	"navIcon": "navbar_navIcon__0ZTU_",
	"profileMenu": "navbar_profileMenu__S3eQh",
	"profileMenuItem": "navbar_profileMenuItem__1f9gz",
	"profileMenuTip": "navbar_profileMenuTip__r4phr"
};


/***/ }),

/***/ 1159:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ RootLayout),
  metadata: () => (/* binding */ metadata)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(6786);
// EXTERNAL MODULE: ./node_modules/next/font/google/target.css?{"path":"src\\app\\layout.js","import":"Inter","arguments":[{"subsets":["latin"]}],"variableName":"inter"}
var target_path_src_app_layout_js_import_Inter_arguments_subsets_latin_variableName_inter_ = __webpack_require__(7155);
var target_path_src_app_layout_js_import_Inter_arguments_subsets_latin_variableName_inter_default = /*#__PURE__*/__webpack_require__.n(target_path_src_app_layout_js_import_Inter_arguments_subsets_latin_variableName_inter_);
// EXTERNAL MODULE: ./src/app/globals.css
var globals = __webpack_require__(5023);
// EXTERNAL MODULE: ./node_modules/next/dist/build/webpack/loaders/next-flight-loader/module-proxy.js
var module_proxy = __webpack_require__(1363);
;// CONCATENATED MODULE: ./src/app/components/navbar.js

const proxy = (0,module_proxy.createProxy)(String.raw`E:\Study Notes\Visual Studio Projects\Learning Next.js\fake-store\src\app\components\navbar.js`)

// Accessing the __esModule property and exporting $$typeof are required here.
// The __esModule getter forces the proxy target to create the default export
// and the $$typeof value is for rendering logic to determine if the module
// is a client boundary.
const { __esModule, $$typeof } = proxy;
const __default__ = proxy.default;


/* harmony default export */ const navbar = (__default__);
// EXTERNAL MODULE: ./node_modules/bootstrap/dist/css/bootstrap.css
var bootstrap = __webpack_require__(8399);
// EXTERNAL MODULE: ./node_modules/react-hot-toast/dist/index.mjs
var dist = __webpack_require__(6014);
;// CONCATENATED MODULE: ./src/app/layout.js






const metadata = {
    title: "Fake Store",
    description: ""
};
function RootLayout({ children }) {
    return /*#__PURE__*/ jsx_runtime_.jsx("html", {
        lang: "en",
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("body", {
            className: (target_path_src_app_layout_js_import_Inter_arguments_subsets_latin_variableName_inter_default()).className,
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx(navbar, {}),
                /*#__PURE__*/ jsx_runtime_.jsx(dist/* Toaster */.x7, {
                    position: "top-center",
                    reverseOrder: false
                }),
                children
            ]
        })
    });
}


/***/ }),

/***/ 3881:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var next_dist_lib_metadata_get_metadata_route__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(85);
/* harmony import */ var next_dist_lib_metadata_get_metadata_route__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_lib_metadata_get_metadata_route__WEBPACK_IMPORTED_MODULE_0__);
  

  /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ((props) => {
    const imageData = {"type":"image/x-icon","sizes":"516x472"}
    const imageUrl = (0,next_dist_lib_metadata_get_metadata_route__WEBPACK_IMPORTED_MODULE_0__.fillMetadataSegment)(".", props.params, "favicon.ico")

    return [{
      ...imageData,
      url: imageUrl + "",
    }]
  });

/***/ }),

/***/ 5023:
/***/ (() => {



/***/ })

};
;