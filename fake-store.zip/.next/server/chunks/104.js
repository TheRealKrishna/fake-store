exports.id = 104;
exports.ids = [104];
exports.modules = {

/***/ 3994:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 1338))

/***/ }),

/***/ 1338:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ ProfileBox)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6786);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _profileBox_module_css__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(3830);
/* harmony import */ var _profileBox_module_css__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_profileBox_module_css__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var next_navigation__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(7114);
/* harmony import */ var next_navigation__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_navigation__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _app_components_loader__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(815);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1440);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react_hot_toast__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(345);
/* __next_internal_client_entry_do_not_use__ default auto */ 





function ProfileBox(props) {
    const router = (0,next_navigation__WEBPACK_IMPORTED_MODULE_1__.useRouter)();
    const pathname = (0,next_navigation__WEBPACK_IMPORTED_MODULE_1__.usePathname)();
    const handleLogout = ()=>{
        react_hot_toast__WEBPACK_IMPORTED_MODULE_4__.toast.promise(new Promise(async (resolve, reject)=>{
            localStorage.removeItem("auth-token");
            if (localStorage.getItem("auth-token")) {
                reject("An Error Occured!");
            } else {
                resolve();
                router.push("/");
            }
        }), {
            loading: "Logging Out...",
            success: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("b", {
                children: "Logged Out Succesfully"
            }),
            error: (error)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("b", {
                    children: error
                })
        }, {
            iconTheme: {
                primary: "red",
                secondary: "#FFFAEE"
            }
        });
    };
    if (!localStorage.getItem("auth-token")) {
        router.push("/auth/login");
        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_app_components_loader__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {});
    } else {
        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            className: "container",
            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: `bg-light ${(_profileBox_module_css__WEBPACK_IMPORTED_MODULE_5___default().profileContainer)} d-flex`,
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: `container ${(_profileBox_module_css__WEBPACK_IMPORTED_MODULE_5___default().navigatePanel)}`,
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: (_profileBox_module_css__WEBPACK_IMPORTED_MODULE_5___default().menuItem),
                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("ul", {
                                style: {
                                    margin: "0px",
                                    paddingLeft: "0px"
                                },
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_3___default()), {
                                        href: "/member/profile",
                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("li", {
                                            className: `${(_profileBox_module_css__WEBPACK_IMPORTED_MODULE_5___default().profileMenuItem)} ${pathname === "/member/profile" ? (_profileBox_module_css__WEBPACK_IMPORTED_MODULE_5___default().profileMenuItemActive) : ""}`,
                                            style: {
                                                listStyle: "none",
                                                padding: "10px 30px",
                                                borderTopLeftRadius: "6px"
                                            },
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                                                    className: "fa-solid fa-user",
                                                    style: {
                                                        color: "orange",
                                                        marginRight: "5px"
                                                    }
                                                }),
                                                "Profile"
                                            ]
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_3___default()), {
                                        href: "/member/address ",
                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("li", {
                                            className: `${(_profileBox_module_css__WEBPACK_IMPORTED_MODULE_5___default().profileMenuItem)} ${pathname === "/member/address" ? (_profileBox_module_css__WEBPACK_IMPORTED_MODULE_5___default().profileMenuItemActive) : ""}`,
                                            style: {
                                                listStyle: "none",
                                                padding: "10px 30px"
                                            },
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                                                    className: "fa-solid fa-address-book",
                                                    style: {
                                                        color: "orange",
                                                        marginRight: "5px"
                                                    }
                                                }),
                                                "Address"
                                            ]
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_3___default()), {
                                        href: "/member/orders",
                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("li", {
                                            className: `${(_profileBox_module_css__WEBPACK_IMPORTED_MODULE_5___default().profileMenuItem)} ${pathname === "/member/orders" ? (_profileBox_module_css__WEBPACK_IMPORTED_MODULE_5___default().profileMenuItemActive) : ""}`,
                                            style: {
                                                listStyle: "none",
                                                padding: "10px 30px"
                                            },
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                                                    className: "fa-solid fa-box",
                                                    style: {
                                                        color: "orange",
                                                        marginRight: "5px"
                                                    }
                                                }),
                                                "Orders"
                                            ]
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_3___default()), {
                                        href: "/member/wishlist",
                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("li", {
                                            className: `${(_profileBox_module_css__WEBPACK_IMPORTED_MODULE_5___default().profileMenuItem)} ${pathname === "/member/wishlist" ? (_profileBox_module_css__WEBPACK_IMPORTED_MODULE_5___default().profileMenuItemActive) : ""}`,
                                            style: {
                                                listStyle: "none",
                                                padding: "10px 30px"
                                            },
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                                                    className: "fa-solid fa-heart",
                                                    style: {
                                                        color: "orange",
                                                        marginRight: "5px"
                                                    }
                                                }),
                                                "Wish List"
                                            ]
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("hr", {}),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                        style: {
                                            cursor: "pointer"
                                        },
                                        onClick: handleLogout,
                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("li", {
                                            className: (_profileBox_module_css__WEBPACK_IMPORTED_MODULE_5___default().profileMenuItem),
                                            style: {
                                                listStyle: "none",
                                                padding: "10px 40px",
                                                border: "none"
                                            },
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                                                    className: "fa-solid fa-power-off",
                                                    style: {
                                                        color: "red",
                                                        marginRight: "5px"
                                                    }
                                                }),
                                                "Logout"
                                            ]
                                        })
                                    })
                                ]
                            })
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: (_profileBox_module_css__WEBPACK_IMPORTED_MODULE_5___default().profileInfo),
                        children: props.element
                    })
                ]
            })
        });
    }
}


/***/ }),

/***/ 3830:
/***/ ((module) => {

// Exports
module.exports = {
	"profileContainer": "profileBox_profileContainer__SdA_2",
	"navigatePanel": "profileBox_navigatePanel__Ut7QV",
	"profileInfo": "profileBox_profileInfo___5YiE",
	"profileMenuItem": "profileBox_profileMenuItem__BiK7Q",
	"profileMenuItemActive": "profileBox_profileMenuItemActive__y__rF"
};


/***/ }),

/***/ 2247:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ RootLayout)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(6786);
// EXTERNAL MODULE: ./node_modules/next/dist/build/webpack/loaders/next-flight-loader/module-proxy.js
var module_proxy = __webpack_require__(1363);
;// CONCATENATED MODULE: ./src/app/components/profileBox.js

const proxy = (0,module_proxy.createProxy)(String.raw`E:\Study Notes\Visual Studio Projects\Learning Next.js\fake-store\src\app\components\profileBox.js`)

// Accessing the __esModule property and exporting $$typeof are required here.
// The __esModule getter forces the proxy target to create the default export
// and the $$typeof value is for rendering logic to determine if the module
// is a client boundary.
const { __esModule, $$typeof } = proxy;
const __default__ = proxy.default;


/* harmony default export */ const profileBox = (__default__);
;// CONCATENATED MODULE: ./src/app/member/layout.js


function RootLayout({ children }) {
    return /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
        children: /*#__PURE__*/ jsx_runtime_.jsx(profileBox, {
            element: children
        })
    });
}


/***/ })

};
;