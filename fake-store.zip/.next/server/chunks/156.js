exports.id = 156;
exports.ids = [156];
exports.modules = {

/***/ 1156:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  Z: () => (/* binding */ GetProducts)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(6786);
// EXTERNAL MODULE: external "next/dist/compiled/react"
var react_ = __webpack_require__(8038);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(2451);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1440);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
// EXTERNAL MODULE: ./node_modules/@fortawesome/fontawesome-free/css/all.min.css
var all_min = __webpack_require__(7100);
// EXTERNAL MODULE: ./src/app/components/product.module.css
var product_module = __webpack_require__(5951);
var product_module_default = /*#__PURE__*/__webpack_require__.n(product_module);
;// CONCATENATED MODULE: ./src/app/components/product.js
/* __next_internal_client_entry_do_not_use__ default auto */ 




function Product(props) {
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
            href: `/product/${props.id}`,
            style: {
                textDecoration: "none"
            },
            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "card",
                style: {
                    width: "20rem",
                    height: "500px"
                },
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "image-container",
                        style: {
                            width: "100%",
                            height: "250px",
                            position: "relative"
                        },
                        children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                            className: "card-img-top",
                            src: props.image,
                            sizes: "5",
                            fill: true,
                            style: {
                                objectFit: "contain"
                            },
                            alt: "Card image cap"
                        })
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "card-body",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("h5", {
                                className: "card-title",
                                children: props.title
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                className: "card-text",
                                children: props.description.slice(0, 100) + "..."
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                                className: "rating-text",
                                style: {
                                    fontSize: "14px"
                                },
                                children: [
                                    props.rating.rate,
                                    /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                        className: "fas fa-star",
                                        style: {
                                            color: "#ffbb00"
                                        }
                                    }),
                                    " (",
                                    props.rating.count,
                                    ")"
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "d-flex justify-content-between",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("h4", {
                                        children: `$${props.price}`
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                        className: `btn btn-warning ${(product_module_default()).addToCart}`,
                                        children: "Add To Cart"
                                    })
                                ]
                            })
                        ]
                    })
                ]
            })
        })
    });
}

// EXTERNAL MODULE: ./src/app/components/loader.js
var loader = __webpack_require__(815);
// EXTERNAL MODULE: ./node_modules/next/navigation.js
var navigation = __webpack_require__(7114);
;// CONCATENATED MODULE: ./src/app/components/getProducts.js
/* __next_internal_client_entry_do_not_use__ default auto */ 





function GetProducts(props) {
    const searchParams = (0,navigation.useSearchParams)();
    let [products, setProducts] = (0,react_.useState)(false);
    const pathname = (0,navigation.usePathname)();
    const displayNoResultsFound = ()=>{
        return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: "container text-center",
            style: {
                marginTop: "150px"
            },
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx("i", {
                    className: "fas fa-triangle-exclamation m-5",
                    style: {
                        fontSize: "100px"
                    }
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                    children: "Sorry! No Results Found!"
                })
            ]
        });
    };
    const fetchProducts = async ()=>{
        if (searchParams.get("search")) {
            const response = await fetch(`https://fakestoreapi.com/products`).then((data)=>data.json()).then((data)=>searchItems(data, searchParams.get("search"))).then((data)=>setProducts(data));
            return response;
        } else if (props.category) {
            const response = await fetch(`https://fakestoreapi.com/products/category/${props.category}`);
            const json = await response.json();
            setProducts(json);
        } else {
            const response = await fetch("https://fakestoreapi.com/products");
            const json = await response.json();
            setProducts(json);
        }
    };
    const searchItems = (dataArray, keyword)=>{
        const normalizedKeyword = keyword.trim().toLowerCase();
        const matches = dataArray.filter((item)=>{
            const normalizedTitle = item.title.toLowerCase();
            const normalizedDescription = item.description.toLowerCase();
            const normalizedCategory = item.category.toLowerCase();
            return normalizedTitle.includes(normalizedKeyword) || normalizedDescription.includes(normalizedKeyword) || normalizedCategory.includes(normalizedKeyword);
        });
        return matches;
    };
    (0,react_.useEffect)(()=>{
        fetchProducts();
    // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []);
    (0,react_.useEffect)(()=>{
        setProducts(null);
        fetchProducts();
    // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [
        searchParams
    ]);
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        children: products ? products.length > 0 ? /*#__PURE__*/ jsx_runtime_.jsx("div", {
            className: "container mt-3",
            children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "row row-cols-4",
                children: products.map((product)=>{
                    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "col mb-2",
                        children: /*#__PURE__*/ jsx_runtime_.jsx(Product, {
                            id: product.id,
                            title: product.title,
                            image: product.image,
                            description: product.description,
                            price: product.price,
                            category: product.category,
                            rating: product.rating
                        })
                    }, product.id);
                })
            })
        }) : displayNoResultsFound() : /*#__PURE__*/ jsx_runtime_.jsx(loader/* default */.Z, {})
    });
}


/***/ }),

/***/ 5951:
/***/ ((module) => {

// Exports
module.exports = {
	"addToCart": "product_addToCart__tU3Lr"
};


/***/ })

};
;