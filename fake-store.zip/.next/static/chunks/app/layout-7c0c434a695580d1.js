(self.webpackChunk_N_E=self.webpackChunk_N_E||[]).push([[185],{1735:function(e,t,a){Promise.resolve().then(a.bind(a,2707)),Promise.resolve().then(a.bind(a,5925)),Promise.resolve().then(a.t.bind(a,1641,23)),Promise.resolve().then(a.t.bind(a,2471,23)),Promise.resolve().then(a.t.bind(a,4699,23))},2707:function(e,t,a){"use strict";a.r(t),a.d(t,{default:function(){return u}});var r=a(7437),s=a(3091),o=a.n(s);a(352);var i=a(1396),n=a.n(i),l=a(4033),c=a(2265),d=a(5925);function u(e){let t=(0,l.usePathname)(),a=(0,l.useRouter)(),s=(0,l.useSearchParams)(),[i,u]=(0,c.useState)(!1),[p,m]=(0,c.useState)(s.get("search")?s.get("search"):"");return(0,c.useEffect)(()=>{u(!1)},[s,a.pathname]),(0,r.jsxs)("div",{children:[(0,r.jsx)("nav",{className:o().navbar,children:(0,r.jsxs)("div",{className:o().pass,children:[(0,r.jsx)("div",{className:o().opp,children:(0,r.jsx)(n(),{href:"/",children:"Fake Store"})}),(0,r.jsxs)("ul",{children:[(0,r.jsx)("li",{className:"".concat(o().navLi," ").concat("/"===t?o().navLiActive:""),children:(0,r.jsx)(n(),{href:"/",children:"Home"})}),(0,r.jsx)("li",{className:"".concat(o().navLi," ").concat("/category/electronics"===t?o().navLiActive:""),children:(0,r.jsx)(n(),{href:"/category/electronics",children:"Electronics"})}),(0,r.jsx)("li",{className:"".concat(o().navLi," ").concat("/category/jewelery"===t?o().navLiActive:""),children:(0,r.jsx)(n(),{href:"/category/jewelery",children:"Jewelery"})}),(0,r.jsx)("li",{className:"".concat(o().navLi," ").concat("/category/men's%20clothing"===t?o().navLiActive:""),children:(0,r.jsx)(n(),{href:"/category/men's clothing",children:"Men's clothing"})}),(0,r.jsx)("li",{className:"".concat(o().navLi," ").concat("/category/women's%20clothing"===t?o().navLiActive:""),children:(0,r.jsx)(n(),{href:"/category/women's clothing",children:"Women's clothing"})})]}),(0,r.jsx)("div",{children:(0,r.jsxs)("form",{onSubmit:e=>{e.preventDefault(),a.push("../?search=".concat(p))},children:[(0,r.jsx)("input",{className:o().navInput,type:"text",id:"search",name:"search",value:p,onChange:e=>{m(e.target.value)},placeholder:"Search..."}),(0,r.jsx)("button",{className:o().navButton,type:"submit",children:(0,r.jsx)("i",{className:"fa-solid fa-magnifying-glass",style:{color:"black"}})})]})}),(0,r.jsxs)("div",{style:{marginRight:"30px"},children:[(0,r.jsx)(n(),{href:"/member/cart",children:(0,r.jsx)("i",{className:o().navIcon+" fas fa-cart-shopping"})}),(0,r.jsx)("i",{onClick:()=>{localStorage.getItem("auth-token")?u(!i):a.push("/member/profile")},className:o().navIcon+" fas fa-circle-user"})]})]})}),i&&(0,r.jsxs)(r.Fragment,{children:[(0,r.jsx)("i",{className:"fas fa-caret-up ".concat(o().profileMenuTip)}),(0,r.jsx)("div",{className:o().profileMenu,children:(0,r.jsxs)("ul",{style:{margin:"0px",paddingLeft:"0px"},children:[(0,r.jsxs)("li",{style:{listStyle:"none",marginBottom:"13px"},children:[(0,r.jsx)("i",{className:"fa-solid fa-user",style:{color:"orange",marginRight:"5px"}}),(0,r.jsx)(n(),{onClick:()=>u(!1),className:o().profileMenuItem,href:"/member/profile",children:"Profile"})]}),(0,r.jsxs)("li",{style:{listStyle:"none",marginBottom:"13px"},children:[(0,r.jsx)("i",{className:"fa-solid fa-address-book",style:{color:"orange",marginRight:"5px"}}),(0,r.jsx)(n(),{onClick:()=>u(!1),className:o().profileMenuItem,href:"/member/address ",children:"Address"})]}),(0,r.jsxs)("li",{style:{listStyle:"none",marginBottom:"13px"},children:[(0,r.jsx)("i",{className:"fa-solid fa-box",style:{color:"orange",marginRight:"5px"}}),(0,r.jsx)(n(),{onClick:()=>u(!1),className:o().profileMenuItem,href:"/member/orders",children:"Orders"})]}),(0,r.jsxs)("li",{style:{listStyle:"none",marginBottom:"13px"},children:[(0,r.jsx)("i",{className:"fa-solid fa-heart",style:{color:"orange",marginRight:"5px"}}),(0,r.jsx)(n(),{onClick:()=>u(!1),className:o().profileMenuItem,href:"/member/wishlist",children:"Wish List"})]}),(0,r.jsx)("hr",{}),(0,r.jsxs)("li",{style:{listStyle:"none",marginBottom:"5px"},children:[(0,r.jsx)("i",{className:"fa-solid fa-power-off",style:{color:"red",marginRight:"5px"}}),(0,r.jsx)("a",{className:o().profileMenuItem,style:{cursor:"pointer"},onClick:()=>{d.toast.promise(new Promise(async(e,t)=>{localStorage.removeItem("auth-token"),localStorage.getItem("auth-token")?t("An Error Occured!"):(u(!i),a.push("/"),e())}),{loading:"Logging Out...",success:(0,r.jsx)("b",{children:"Logged Out Succesfully"}),error:e=>(0,r.jsx)("b",{children:e})},{iconTheme:{primary:"red",secondary:"#FFFAEE"}})},children:"Logout"})]})]})})]})]})}},352:function(){},4699:function(){},2471:function(){},3091:function(e){e.exports={navbar:"navbar_navbar__BJuG4",pass:"navbar_pass___mi9N",opp:"navbar_opp__bLKdW",navLi:"navbar_navLi___EPrp",navLiActive:"navbar_navLiActive___Oznb",navButton:"navbar_navButton__h9oCx",navLoginButton:"navbar_navLoginButton__rHsEQ",navInput:"navbar_navInput__U2hHg",navIcon:"navbar_navIcon__0ZTU_",profileMenu:"navbar_profileMenu__S3eQh",profileMenuItem:"navbar_profileMenuItem__1f9gz",profileMenuTip:"navbar_profileMenuTip__r4phr"}},1641:function(e){e.exports={style:{fontFamily:"'__Inter_20951f', '__Inter_Fallback_20951f'",fontStyle:"normal"},className:"__className_20951f"}},5925:function(e,t,a){"use strict";let r,s;a.r(t),a.d(t,{CheckmarkIcon:function(){return W},ErrorIcon:function(){return R},LoaderIcon:function(){return U},ToastBar:function(){return ee},ToastIcon:function(){return q},Toaster:function(){return es},default:function(){return eo},resolveValue:function(){return N},toast:function(){return z},useToaster:function(){return H},useToasterStore:function(){return P}});var o,i=a(2265);let n={data:""},l=e=>"object"==typeof window?((e?e.querySelector("#_goober"):window._goober)||Object.assign((e||document.head).appendChild(document.createElement("style")),{innerHTML:" ",id:"_goober"})).firstChild:e||n,c=/(?:([\u0080-\uFFFF\w-%@]+) *:? *([^{;]+?);|([^;}{]*?) *{)|(}\s*)/g,d=/\/\*[^]*?\*\/|  +/g,u=/\n+/g,p=(e,t)=>{let a="",r="",s="";for(let o in e){let i=e[o];"@"==o[0]?"i"==o[1]?a=o+" "+i+";":r+="f"==o[1]?p(i,o):o+"{"+p(i,"k"==o[1]?"":t)+"}":"object"==typeof i?r+=p(i,t?t.replace(/([^,])+/g,e=>o.replace(/(^:.*)|([^,])+/g,t=>/&/.test(t)?t.replace(/&/g,e):e?e+" "+t:t)):o):null!=i&&(o=/^--/.test(o)?o:o.replace(/[A-Z]/g,"-$&").toLowerCase(),s+=p.p?p.p(o,i):o+":"+i+";")}return a+(t&&s?t+"{"+s+"}":s)+r},m={},f=e=>{if("object"==typeof e){let t="";for(let a in e)t+=a+f(e[a]);return t}return e},h=(e,t,a,r,s)=>{var o;let i=f(e),n=m[i]||(m[i]=(e=>{let t=0,a=11;for(;t<e.length;)a=101*a+e.charCodeAt(t++)>>>0;return"go"+a})(i));if(!m[n]){let t=i!==e?e:(e=>{let t,a,r=[{}];for(;t=c.exec(e.replace(d,""));)t[4]?r.shift():t[3]?(a=t[3].replace(u," ").trim(),r.unshift(r[0][a]=r[0][a]||{})):r[0][t[1]]=t[2].replace(u," ").trim();return r[0]})(e);m[n]=p(s?{["@keyframes "+n]:t}:t,a?"":"."+n)}let l=a&&m.g?m.g:null;return a&&(m.g=m[n]),o=m[n],l?t.data=t.data.replace(l,o):-1===t.data.indexOf(o)&&(t.data=r?o+t.data:t.data+o),n},g=(e,t,a)=>e.reduce((e,r,s)=>{let o=t[s];if(o&&o.call){let e=o(a),t=e&&e.props&&e.props.className||/^go/.test(e)&&e;o=t?"."+t:e&&"object"==typeof e?e.props?"":p(e,""):!1===e?"":e}return e+r+(null==o?"":o)},"");function y(e){let t=this||{},a=e.call?e(t.p):e;return h(a.unshift?a.raw?g(a,[].slice.call(arguments,1),t.p):a.reduce((e,a)=>Object.assign(e,a&&a.call?a(t.p):a),{}):a,l(t.target),t.g,t.o,t.k)}y.bind({g:1});let v,x,b,j=y.bind({k:1});function _(e,t){let a=this||{};return function(){let r=arguments;function s(o,i){let n=Object.assign({},o),l=n.className||s.className;a.p=Object.assign({theme:x&&x()},n),a.o=/ *go\d+/.test(l),n.className=y.apply(a,r)+(l?" "+l:""),t&&(n.ref=i);let c=e;return e[0]&&(c=n.as||e,delete n.as),b&&c[0]&&b(n),v(c,n)}return t?t(s):s}}var w=e=>"function"==typeof e,N=(e,t)=>w(e)?e(t):e,k=(r=0,()=>(++r).toString()),E=()=>{if(void 0===s&&"u">typeof window){let e=matchMedia("(prefers-reduced-motion: reduce)");s=!e||e.matches}return s},I=new Map,L=e=>{if(I.has(e))return;let t=setTimeout(()=>{I.delete(e),A({type:4,toastId:e})},1e3);I.set(e,t)},C=e=>{let t=I.get(e);t&&clearTimeout(t)},S=(e,t)=>{switch(t.type){case 0:return{...e,toasts:[t.toast,...e.toasts].slice(0,20)};case 1:return t.toast.id&&C(t.toast.id),{...e,toasts:e.toasts.map(e=>e.id===t.toast.id?{...e,...t.toast}:e)};case 2:let{toast:a}=t;return e.toasts.find(e=>e.id===a.id)?S(e,{type:1,toast:a}):S(e,{type:0,toast:a});case 3:let{toastId:r}=t;return r?L(r):e.toasts.forEach(e=>{L(e.id)}),{...e,toasts:e.toasts.map(e=>e.id===r||void 0===r?{...e,visible:!1}:e)};case 4:return void 0===t.toastId?{...e,toasts:[]}:{...e,toasts:e.toasts.filter(e=>e.id!==t.toastId)};case 5:return{...e,pausedAt:t.time};case 6:let s=t.time-(e.pausedAt||0);return{...e,pausedAt:void 0,toasts:e.toasts.map(e=>({...e,pauseDuration:e.pauseDuration+s}))}}},M=[],O={toasts:[],pausedAt:void 0},A=e=>{O=S(O,e),M.forEach(e=>{e(O)})},$={blank:4e3,error:4e3,success:2e3,loading:1/0,custom:4e3},P=(e={})=>{let[t,a]=(0,i.useState)(O);(0,i.useEffect)(()=>(M.push(a),()=>{let e=M.indexOf(a);e>-1&&M.splice(e,1)}),[t]);let r=t.toasts.map(t=>{var a,r;return{...e,...e[t.type],...t,duration:t.duration||(null==(a=e[t.type])?void 0:a.duration)||(null==e?void 0:e.duration)||$[t.type],style:{...e.style,...null==(r=e[t.type])?void 0:r.style,...t.style}}});return{...t,toasts:r}},T=(e,t="blank",a)=>({createdAt:Date.now(),visible:!0,type:t,ariaProps:{role:"status","aria-live":"polite"},message:e,pauseDuration:0,...a,id:(null==a?void 0:a.id)||k()}),B=e=>(t,a)=>{let r=T(t,e,a);return A({type:2,toast:r}),r.id},z=(e,t)=>B("blank")(e,t);z.error=B("error"),z.success=B("success"),z.loading=B("loading"),z.custom=B("custom"),z.dismiss=e=>{A({type:3,toastId:e})},z.remove=e=>A({type:4,toastId:e}),z.promise=(e,t,a)=>{let r=z.loading(t.loading,{...a,...null==a?void 0:a.loading});return e.then(e=>(z.success(N(t.success,e),{id:r,...a,...null==a?void 0:a.success}),e)).catch(e=>{z.error(N(t.error,e),{id:r,...a,...null==a?void 0:a.error})}),e};var F=(e,t)=>{A({type:1,toast:{id:e,height:t}})},D=()=>{A({type:5,time:Date.now()})},H=e=>{let{toasts:t,pausedAt:a}=P(e);(0,i.useEffect)(()=>{if(a)return;let e=Date.now(),r=t.map(t=>{if(t.duration===1/0)return;let a=(t.duration||0)+t.pauseDuration-(e-t.createdAt);if(a<0){t.visible&&z.dismiss(t.id);return}return setTimeout(()=>z.dismiss(t.id),a)});return()=>{r.forEach(e=>e&&clearTimeout(e))}},[t,a]);let r=(0,i.useCallback)(()=>{a&&A({type:6,time:Date.now()})},[a]),s=(0,i.useCallback)((e,a)=>{let{reverseOrder:r=!1,gutter:s=8,defaultPosition:o}=a||{},i=t.filter(t=>(t.position||o)===(e.position||o)&&t.height),n=i.findIndex(t=>t.id===e.id),l=i.filter((e,t)=>t<n&&e.visible).length;return i.filter(e=>e.visible).slice(...r?[l+1]:[0,l]).reduce((e,t)=>e+(t.height||0)+s,0)},[t]);return{toasts:t,handlers:{updateHeight:F,startPause:D,endPause:r,calculateOffset:s}}},R=_("div")`
  width: 20px;
  opacity: 0;
  height: 20px;
  border-radius: 10px;
  background: ${e=>e.primary||"#ff4b4b"};
  position: relative;
  transform: rotate(45deg);

  animation: ${j`
from {
  transform: scale(0) rotate(45deg);
	opacity: 0;
}
to {
 transform: scale(1) rotate(45deg);
  opacity: 1;
}`} 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275)
    forwards;
  animation-delay: 100ms;

  &:after,
  &:before {
    content: '';
    animation: ${j`
from {
  transform: scale(0);
  opacity: 0;
}
to {
  transform: scale(1);
  opacity: 1;
}`} 0.15s ease-out forwards;
    animation-delay: 150ms;
    position: absolute;
    border-radius: 3px;
    opacity: 0;
    background: ${e=>e.secondary||"#fff"};
    bottom: 9px;
    left: 4px;
    height: 2px;
    width: 12px;
  }

  &:before {
    animation: ${j`
from {
  transform: scale(0) rotate(90deg);
	opacity: 0;
}
to {
  transform: scale(1) rotate(90deg);
	opacity: 1;
}`} 0.15s ease-out forwards;
    animation-delay: 180ms;
    transform: rotate(90deg);
  }
`,U=_("div")`
  width: 12px;
  height: 12px;
  box-sizing: border-box;
  border: 2px solid;
  border-radius: 100%;
  border-color: ${e=>e.secondary||"#e0e0e0"};
  border-right-color: ${e=>e.primary||"#616161"};
  animation: ${j`
  from {
    transform: rotate(0deg);
  }
  to {
    transform: rotate(360deg);
  }
`} 1s linear infinite;
`,W=_("div")`
  width: 20px;
  opacity: 0;
  height: 20px;
  border-radius: 10px;
  background: ${e=>e.primary||"#61d345"};
  position: relative;
  transform: rotate(45deg);

  animation: ${j`
from {
  transform: scale(0) rotate(45deg);
	opacity: 0;
}
to {
  transform: scale(1) rotate(45deg);
	opacity: 1;
}`} 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275)
    forwards;
  animation-delay: 100ms;
  &:after {
    content: '';
    box-sizing: border-box;
    animation: ${j`
0% {
	height: 0;
	width: 0;
	opacity: 0;
}
40% {
  height: 0;
	width: 6px;
	opacity: 1;
}
100% {
  opacity: 1;
  height: 10px;
}`} 0.2s ease-out forwards;
    opacity: 0;
    animation-delay: 200ms;
    position: absolute;
    border-right: 2px solid;
    border-bottom: 2px solid;
    border-color: ${e=>e.secondary||"#fff"};
    bottom: 6px;
    left: 6px;
    height: 10px;
    width: 6px;
  }
`,J=_("div")`
  position: absolute;
`,Q=_("div")`
  position: relative;
  display: flex;
  justify-content: center;
  align-items: center;
  min-width: 20px;
  min-height: 20px;
`,Z=_("div")`
  position: relative;
  transform: scale(0.6);
  opacity: 0.4;
  min-width: 20px;
  animation: ${j`
from {
  transform: scale(0.6);
  opacity: 0.4;
}
to {
  transform: scale(1);
  opacity: 1;
}`} 0.3s 0.12s cubic-bezier(0.175, 0.885, 0.32, 1.275)
    forwards;
`,q=({toast:e})=>{let{icon:t,type:a,iconTheme:r}=e;return void 0!==t?"string"==typeof t?i.createElement(Z,null,t):t:"blank"===a?null:i.createElement(Q,null,i.createElement(U,{...r}),"loading"!==a&&i.createElement(J,null,"error"===a?i.createElement(R,{...r}):i.createElement(W,{...r})))},G=e=>`
0% {transform: translate3d(0,${-200*e}%,0) scale(.6); opacity:.5;}
100% {transform: translate3d(0,0,0) scale(1); opacity:1;}
`,K=e=>`
0% {transform: translate3d(0,0,-1px) scale(1); opacity:1;}
100% {transform: translate3d(0,${-150*e}%,-1px) scale(.6); opacity:0;}
`,V=_("div")`
  display: flex;
  align-items: center;
  background: #fff;
  color: #363636;
  line-height: 1.3;
  will-change: transform;
  box-shadow: 0 3px 10px rgba(0, 0, 0, 0.1), 0 3px 3px rgba(0, 0, 0, 0.05);
  max-width: 350px;
  pointer-events: auto;
  padding: 8px 10px;
  border-radius: 8px;
`,Y=_("div")`
  display: flex;
  justify-content: center;
  margin: 4px 10px;
  color: inherit;
  flex: 1 1 auto;
  white-space: pre-line;
`,X=(e,t)=>{let a=e.includes("top")?1:-1,[r,s]=E()?["0%{opacity:0;} 100%{opacity:1;}","0%{opacity:1;} 100%{opacity:0;}"]:[G(a),K(a)];return{animation:t?`${j(r)} 0.35s cubic-bezier(.21,1.02,.73,1) forwards`:`${j(s)} 0.4s forwards cubic-bezier(.06,.71,.55,1)`}},ee=i.memo(({toast:e,position:t,style:a,children:r})=>{let s=e.height?X(e.position||t||"top-center",e.visible):{opacity:0},o=i.createElement(q,{toast:e}),n=i.createElement(Y,{...e.ariaProps},N(e.message,e));return i.createElement(V,{className:e.className,style:{...s,...a,...e.style}},"function"==typeof r?r({icon:o,message:n}):i.createElement(i.Fragment,null,o,n))});o=i.createElement,p.p=void 0,v=o,x=void 0,b=void 0;var et=({id:e,className:t,style:a,onHeightUpdate:r,children:s})=>{let o=i.useCallback(t=>{if(t){let a=()=>{r(e,t.getBoundingClientRect().height)};a(),new MutationObserver(a).observe(t,{subtree:!0,childList:!0,characterData:!0})}},[e,r]);return i.createElement("div",{ref:o,className:t,style:a},s)},ea=(e,t)=>{let a=e.includes("top"),r=e.includes("center")?{justifyContent:"center"}:e.includes("right")?{justifyContent:"flex-end"}:{};return{left:0,right:0,display:"flex",position:"absolute",transition:E()?void 0:"all 230ms cubic-bezier(.21,1.02,.73,1)",transform:`translateY(${t*(a?1:-1)}px)`,...a?{top:0}:{bottom:0},...r}},er=y`
  z-index: 9999;
  > * {
    pointer-events: auto;
  }
`,es=({reverseOrder:e,position:t="top-center",toastOptions:a,gutter:r,children:s,containerStyle:o,containerClassName:n})=>{let{toasts:l,handlers:c}=H(a);return i.createElement("div",{style:{position:"fixed",zIndex:9999,top:16,left:16,right:16,bottom:16,pointerEvents:"none",...o},className:n,onMouseEnter:c.startPause,onMouseLeave:c.endPause},l.map(a=>{let o=a.position||t,n=ea(o,c.calculateOffset(a,{reverseOrder:e,gutter:r,defaultPosition:t}));return i.createElement(et,{id:a.id,key:a.id,onHeightUpdate:c.updateHeight,className:a.visible?er:"",style:n},"custom"===a.type?N(a.message,a):s?s(a):i.createElement(ee,{toast:a,position:o}))}))},eo=z}},function(e){e.O(0,[866,972,569,971,596,744],function(){return e(e.s=1735)}),_N_E=e.O()}]);