(self.webpackChunk_N_E=self.webpackChunk_N_E||[]).push([[47],{2513:function(e,t,a){Promise.resolve().then(a.bind(a,1364))},1364:function(e,t,a){"use strict";a.r(t),a.d(t,{default:function(){return g}});var r=a(7437),o=a(6691),s=a.n(o),i=a(5973),n=a.n(i),l={src:"/_next/static/media/login.96da1301.svg",height:300,width:300,blurWidth:0,blurHeight:0};a(352);var c=a(2265),d=a(5925),u=a(4033),p=a(1396),m=a.n(p),f=a(5957);function g(){let e=(0,u.useRouter)(),[t,a]=(0,c.useState)({email:"",password:""}),[o,i]=(0,c.useState)("password"),[p,g]=(0,c.useState)("fa-eye-slash"),h=(0,c.useRef)(),y=async e=>{if(a({...t,[e.target.name]:e.target.value}),"password"===e.target.name||"confirmPassword"===e.target.name){var r,o;"confirmPassword"===e.target.name&&e.target.value!==t.password?null===(r=h.current)||void 0===r||r.setCustomValidity("Passwords Do Not Match"):null===(o=h.current)||void 0===o||o.setCustomValidity("")}};return localStorage.getItem("auth-token")?(e.push("/"),(0,r.jsx)(f.Z,{})):(0,r.jsx)(r.Fragment,{children:(0,r.jsx)("form",{onSubmit:a=>{a.preventDefault(),d.default.promise(new Promise(async(a,r)=>{let o=await fetch("/api/auth/login",{headers:{"Content-Type":"application/json"},method:"POST",body:JSON.stringify({email:t.email,password:t.password})}),s=await o.json();s.success?(localStorage.setItem("auth-token",s.token),a(),e.back()):r(s.error)}),{loading:"Logging In..",success:(0,r.jsx)("b",{children:"Logged In Succesfully!"}),error:e=>(0,r.jsx)("b",{children:e})})},children:(0,r.jsxs)("div",{className:"container mt-5 d-flex",style:{height:"500px",width:"1000px"},children:[(0,r.jsxs)("div",{className:"container bg-warning ".concat(n().yellowBox),style:{flex:"1",borderTop:"1px solid black"},children:[(0,r.jsx)("h2",{style:{fontFamily:"revert-layer",fontWeight:"bold",padding:"5px 30%",marginTop:"35px"},children:"Log In"}),(0,r.jsx)("h6",{style:{color:"grey"},children:"Get access to your Orders, Wishlist and Recommendations"}),(0,r.jsx)(s(),{src:l,style:{position:"absolute",bottom:"100px"},alt:"SignUp Image"})]}),(0,r.jsxs)("div",{className:"container bg-light ".concat(n().lightBox),style:{flex:"2"},children:[(0,r.jsxs)("div",{className:n().inputs,children:[(0,r.jsx)("i",{className:"fa-solid fa-envelope",style:{color:"#ffc107",marginTop:"7px"}}),(0,r.jsx)("input",{required:!0,type:"email",onChange:y,name:"email",value:t.email,className:"bg-light",placeholder:"email"})]}),(0,r.jsxs)("div",{className:n().inputs,children:[(0,r.jsx)("i",{className:"fa-solid fa-lock",style:{color:"#ffc107",marginTop:"7px"}}),(0,r.jsx)("input",{required:!0,type:o,onChange:y,name:"password",value:t.password,minLength:8,className:"bg-light",placeholder:"password"}),(0,r.jsx)("i",{className:"fa-solid ".concat(p),onClick:()=>{"password"===o?(i("text"),g("fa-eye")):(i("password"),g("fa-eye-slash"))},style:{color:"#000000",position:"absolute",right:"360px",marginTop:"7px",cursor:"pointer"}})]}),(0,r.jsx)("div",{style:{marginTop:"20px",marginBottom:"60px"},children:(0,r.jsx)("p",{style:{position:"absolute",left:"720px"},children:(0,r.jsx)("a",{style:{textDecoration:"none"},href:"/auth/forgot-password",target:"_blank",children:"Forgot Password"})})}),(0,r.jsx)("div",{className:n().inputs,style:{margin:"0px"},children:(0,r.jsx)("button",{className:"btn btn-warning",style:{marginLeft:"30px"},type:"submit",children:"Log In"})}),(0,r.jsx)("div",{style:{marginTop:"90px"},children:(0,r.jsxs)("p",{style:{position:"absolute",left:"720px"},children:["Not a member yet? ",(0,r.jsx)(m(),{style:{textDecoration:"none"},href:"/auth/signup",children:"Create Account"})]})})]})]})})})}},5957:function(e,t,a){"use strict";a.d(t,{Z:function(){return i}});var r=a(7437),o=a(57),s=a.n(o);function i(){return(0,r.jsx)("span",{className:s().loader,style:{marginTop:"250px"}})}},5973:function(e){e.exports={yellowBox:"page_yellowBox__ybsh1",lightBox:"page_lightBox___D0Oe",inputs:"page_inputs__jADBE"}},57:function(e){e.exports={loader:"loader_loader__7XEVx",animloader:"loader_animloader__93aPY"}},5925:function(e,t,a){"use strict";let r,o;a.r(t),a.d(t,{CheckmarkIcon:function(){return q},ErrorIcon:function(){return R},LoaderIcon:function(){return V},ToastBar:function(){return ee},ToastIcon:function(){return Y},Toaster:function(){return eo},default:function(){return es},resolveValue:function(){return N},toast:function(){return B},useToaster:function(){return H},useToasterStore:function(){return A}});var s,i=a(2265);let n={data:""},l=e=>"object"==typeof window?((e?e.querySelector("#_goober"):window._goober)||Object.assign((e||document.head).appendChild(document.createElement("style")),{innerHTML:" ",id:"_goober"})).firstChild:e||n,c=/(?:([\u0080-\uFFFF\w-%@]+) *:? *([^{;]+?);|([^;}{]*?) *{)|(}\s*)/g,d=/\/\*[^]*?\*\/|  +/g,u=/\n+/g,p=(e,t)=>{let a="",r="",o="";for(let s in e){let i=e[s];"@"==s[0]?"i"==s[1]?a=s+" "+i+";":r+="f"==s[1]?p(i,s):s+"{"+p(i,"k"==s[1]?"":t)+"}":"object"==typeof i?r+=p(i,t?t.replace(/([^,])+/g,e=>s.replace(/(^:.*)|([^,])+/g,t=>/&/.test(t)?t.replace(/&/g,e):e?e+" "+t:t)):s):null!=i&&(s=/^--/.test(s)?s:s.replace(/[A-Z]/g,"-$&").toLowerCase(),o+=p.p?p.p(s,i):s+":"+i+";")}return a+(t&&o?t+"{"+o+"}":o)+r},m={},f=e=>{if("object"==typeof e){let t="";for(let a in e)t+=a+f(e[a]);return t}return e},g=(e,t,a,r,o)=>{var s;let i=f(e),n=m[i]||(m[i]=(e=>{let t=0,a=11;for(;t<e.length;)a=101*a+e.charCodeAt(t++)>>>0;return"go"+a})(i));if(!m[n]){let t=i!==e?e:(e=>{let t,a,r=[{}];for(;t=c.exec(e.replace(d,""));)t[4]?r.shift():t[3]?(a=t[3].replace(u," ").trim(),r.unshift(r[0][a]=r[0][a]||{})):r[0][t[1]]=t[2].replace(u," ").trim();return r[0]})(e);m[n]=p(o?{["@keyframes "+n]:t}:t,a?"":"."+n)}let l=a&&m.g?m.g:null;return a&&(m.g=m[n]),s=m[n],l?t.data=t.data.replace(l,s):-1===t.data.indexOf(s)&&(t.data=r?s+t.data:t.data+s),n},h=(e,t,a)=>e.reduce((e,r,o)=>{let s=t[o];if(s&&s.call){let e=s(a),t=e&&e.props&&e.props.className||/^go/.test(e)&&e;s=t?"."+t:e&&"object"==typeof e?e.props?"":p(e,""):!1===e?"":e}return e+r+(null==s?"":s)},"");function y(e){let t=this||{},a=e.call?e(t.p):e;return g(a.unshift?a.raw?h(a,[].slice.call(arguments,1),t.p):a.reduce((e,a)=>Object.assign(e,a&&a.call?a(t.p):a),{}):a,l(t.target),t.g,t.o,t.k)}y.bind({g:1});let x,b,v,w=y.bind({k:1});function j(e,t){let a=this||{};return function(){let r=arguments;function o(s,i){let n=Object.assign({},s),l=n.className||o.className;a.p=Object.assign({theme:b&&b()},n),a.o=/ *go\d+/.test(l),n.className=y.apply(a,r)+(l?" "+l:""),t&&(n.ref=i);let c=e;return e[0]&&(c=n.as||e,delete n.as),v&&c[0]&&v(n),x(c,n)}return t?t(o):o}}var k=e=>"function"==typeof e,N=(e,t)=>k(e)?e(t):e,E=(r=0,()=>(++r).toString()),_=()=>{if(void 0===o&&"u">typeof window){let e=matchMedia("(prefers-reduced-motion: reduce)");o=!e||e.matches}return o},C=new Map,T=e=>{if(C.has(e))return;let t=setTimeout(()=>{C.delete(e),D({type:4,toastId:e})},1e3);C.set(e,t)},I=e=>{let t=C.get(e);t&&clearTimeout(t)},O=(e,t)=>{switch(t.type){case 0:return{...e,toasts:[t.toast,...e.toasts].slice(0,20)};case 1:return t.toast.id&&I(t.toast.id),{...e,toasts:e.toasts.map(e=>e.id===t.toast.id?{...e,...t.toast}:e)};case 2:let{toast:a}=t;return e.toasts.find(e=>e.id===a.id)?O(e,{type:1,toast:a}):O(e,{type:0,toast:a});case 3:let{toastId:r}=t;return r?T(r):e.toasts.forEach(e=>{T(e.id)}),{...e,toasts:e.toasts.map(e=>e.id===r||void 0===r?{...e,visible:!1}:e)};case 4:return void 0===t.toastId?{...e,toasts:[]}:{...e,toasts:e.toasts.filter(e=>e.id!==t.toastId)};case 5:return{...e,pausedAt:t.time};case 6:let o=t.time-(e.pausedAt||0);return{...e,pausedAt:void 0,toasts:e.toasts.map(e=>({...e,pauseDuration:e.pauseDuration+o}))}}},$=[],P={toasts:[],pausedAt:void 0},D=e=>{P=O(P,e),$.forEach(e=>{e(P)})},S={blank:4e3,error:4e3,success:2e3,loading:1/0,custom:4e3},A=(e={})=>{let[t,a]=(0,i.useState)(P);(0,i.useEffect)(()=>($.push(a),()=>{let e=$.indexOf(a);e>-1&&$.splice(e,1)}),[t]);let r=t.toasts.map(t=>{var a,r;return{...e,...e[t.type],...t,duration:t.duration||(null==(a=e[t.type])?void 0:a.duration)||(null==e?void 0:e.duration)||S[t.type],style:{...e.style,...null==(r=e[t.type])?void 0:r.style,...t.style}}});return{...t,toasts:r}},L=(e,t="blank",a)=>({createdAt:Date.now(),visible:!0,type:t,ariaProps:{role:"status","aria-live":"polite"},message:e,pauseDuration:0,...a,id:(null==a?void 0:a.id)||E()}),z=e=>(t,a)=>{let r=L(t,e,a);return D({type:2,toast:r}),r.id},B=(e,t)=>z("blank")(e,t);B.error=z("error"),B.success=z("success"),B.loading=z("loading"),B.custom=z("custom"),B.dismiss=e=>{D({type:3,toastId:e})},B.remove=e=>D({type:4,toastId:e}),B.promise=(e,t,a)=>{let r=B.loading(t.loading,{...a,...null==a?void 0:a.loading});return e.then(e=>(B.success(N(t.success,e),{id:r,...a,...null==a?void 0:a.success}),e)).catch(e=>{B.error(N(t.error,e),{id:r,...a,...null==a?void 0:a.error})}),e};var F=(e,t)=>{D({type:1,toast:{id:e,height:t}})},M=()=>{D({type:5,time:Date.now()})},H=e=>{let{toasts:t,pausedAt:a}=A(e);(0,i.useEffect)(()=>{if(a)return;let e=Date.now(),r=t.map(t=>{if(t.duration===1/0)return;let a=(t.duration||0)+t.pauseDuration-(e-t.createdAt);if(a<0){t.visible&&B.dismiss(t.id);return}return setTimeout(()=>B.dismiss(t.id),a)});return()=>{r.forEach(e=>e&&clearTimeout(e))}},[t,a]);let r=(0,i.useCallback)(()=>{a&&D({type:6,time:Date.now()})},[a]),o=(0,i.useCallback)((e,a)=>{let{reverseOrder:r=!1,gutter:o=8,defaultPosition:s}=a||{},i=t.filter(t=>(t.position||s)===(e.position||s)&&t.height),n=i.findIndex(t=>t.id===e.id),l=i.filter((e,t)=>t<n&&e.visible).length;return i.filter(e=>e.visible).slice(...r?[l+1]:[0,l]).reduce((e,t)=>e+(t.height||0)+o,0)},[t]);return{toasts:t,handlers:{updateHeight:F,startPause:M,endPause:r,calculateOffset:o}}},R=j("div")`
  width: 20px;
  opacity: 0;
  height: 20px;
  border-radius: 10px;
  background: ${e=>e.primary||"#ff4b4b"};
  position: relative;
  transform: rotate(45deg);

  animation: ${w`
from {
  transform: scale(0) rotate(45deg);
	opacity: 0;
}
to {
 transform: scale(1) rotate(45deg);
  opacity: 1;
}`} 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275)
    forwards;
  animation-delay: 100ms;

  &:after,
  &:before {
    content: '';
    animation: ${w`
from {
  transform: scale(0);
  opacity: 0;
}
to {
  transform: scale(1);
  opacity: 1;
}`} 0.15s ease-out forwards;
    animation-delay: 150ms;
    position: absolute;
    border-radius: 3px;
    opacity: 0;
    background: ${e=>e.secondary||"#fff"};
    bottom: 9px;
    left: 4px;
    height: 2px;
    width: 12px;
  }

  &:before {
    animation: ${w`
from {
  transform: scale(0) rotate(90deg);
	opacity: 0;
}
to {
  transform: scale(1) rotate(90deg);
	opacity: 1;
}`} 0.15s ease-out forwards;
    animation-delay: 180ms;
    transform: rotate(90deg);
  }
`,V=j("div")`
  width: 12px;
  height: 12px;
  box-sizing: border-box;
  border: 2px solid;
  border-radius: 100%;
  border-color: ${e=>e.secondary||"#e0e0e0"};
  border-right-color: ${e=>e.primary||"#616161"};
  animation: ${w`
  from {
    transform: rotate(0deg);
  }
  to {
    transform: rotate(360deg);
  }
`} 1s linear infinite;
`,q=j("div")`
  width: 20px;
  opacity: 0;
  height: 20px;
  border-radius: 10px;
  background: ${e=>e.primary||"#61d345"};
  position: relative;
  transform: rotate(45deg);

  animation: ${w`
from {
  transform: scale(0) rotate(45deg);
	opacity: 0;
}
to {
  transform: scale(1) rotate(45deg);
	opacity: 1;
}`} 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275)
    forwards;
  animation-delay: 100ms;
  &:after {
    content: '';
    box-sizing: border-box;
    animation: ${w`
0% {
	height: 0;
	width: 0;
	opacity: 0;
}
40% {
  height: 0;
	width: 6px;
	opacity: 1;
}
100% {
  opacity: 1;
  height: 10px;
}`} 0.2s ease-out forwards;
    opacity: 0;
    animation-delay: 200ms;
    position: absolute;
    border-right: 2px solid;
    border-bottom: 2px solid;
    border-color: ${e=>e.secondary||"#fff"};
    bottom: 6px;
    left: 6px;
    height: 10px;
    width: 6px;
  }
`,U=j("div")`
  position: absolute;
`,W=j("div")`
  position: relative;
  display: flex;
  justify-content: center;
  align-items: center;
  min-width: 20px;
  min-height: 20px;
`,Z=j("div")`
  position: relative;
  transform: scale(0.6);
  opacity: 0.4;
  min-width: 20px;
  animation: ${w`
from {
  transform: scale(0.6);
  opacity: 0.4;
}
to {
  transform: scale(1);
  opacity: 1;
}`} 0.3s 0.12s cubic-bezier(0.175, 0.885, 0.32, 1.275)
    forwards;
`,Y=({toast:e})=>{let{icon:t,type:a,iconTheme:r}=e;return void 0!==t?"string"==typeof t?i.createElement(Z,null,t):t:"blank"===a?null:i.createElement(W,null,i.createElement(V,{...r}),"loading"!==a&&i.createElement(U,null,"error"===a?i.createElement(R,{...r}):i.createElement(q,{...r})))},G=e=>`
0% {transform: translate3d(0,${-200*e}%,0) scale(.6); opacity:.5;}
100% {transform: translate3d(0,0,0) scale(1); opacity:1;}
`,J=e=>`
0% {transform: translate3d(0,0,-1px) scale(1); opacity:1;}
100% {transform: translate3d(0,${-150*e}%,-1px) scale(.6); opacity:0;}
`,X=j("div")`
  display: flex;
  align-items: center;
  background: #fff;
  color: #363636;
  line-height: 1.3;
  will-change: transform;
  box-shadow: 0 3px 10px rgba(0, 0, 0, 0.1), 0 3px 3px rgba(0, 0, 0, 0.05);
  max-width: 350px;
  pointer-events: auto;
  padding: 8px 10px;
  border-radius: 8px;
`,K=j("div")`
  display: flex;
  justify-content: center;
  margin: 4px 10px;
  color: inherit;
  flex: 1 1 auto;
  white-space: pre-line;
`,Q=(e,t)=>{let a=e.includes("top")?1:-1,[r,o]=_()?["0%{opacity:0;} 100%{opacity:1;}","0%{opacity:1;} 100%{opacity:0;}"]:[G(a),J(a)];return{animation:t?`${w(r)} 0.35s cubic-bezier(.21,1.02,.73,1) forwards`:`${w(o)} 0.4s forwards cubic-bezier(.06,.71,.55,1)`}},ee=i.memo(({toast:e,position:t,style:a,children:r})=>{let o=e.height?Q(e.position||t||"top-center",e.visible):{opacity:0},s=i.createElement(Y,{toast:e}),n=i.createElement(K,{...e.ariaProps},N(e.message,e));return i.createElement(X,{className:e.className,style:{...o,...a,...e.style}},"function"==typeof r?r({icon:s,message:n}):i.createElement(i.Fragment,null,s,n))});s=i.createElement,p.p=void 0,x=s,b=void 0,v=void 0;var et=({id:e,className:t,style:a,onHeightUpdate:r,children:o})=>{let s=i.useCallback(t=>{if(t){let a=()=>{r(e,t.getBoundingClientRect().height)};a(),new MutationObserver(a).observe(t,{subtree:!0,childList:!0,characterData:!0})}},[e,r]);return i.createElement("div",{ref:s,className:t,style:a},o)},ea=(e,t)=>{let a=e.includes("top"),r=e.includes("center")?{justifyContent:"center"}:e.includes("right")?{justifyContent:"flex-end"}:{};return{left:0,right:0,display:"flex",position:"absolute",transition:_()?void 0:"all 230ms cubic-bezier(.21,1.02,.73,1)",transform:`translateY(${t*(a?1:-1)}px)`,...a?{top:0}:{bottom:0},...r}},er=y`
  z-index: 9999;
  > * {
    pointer-events: auto;
  }
`,eo=({reverseOrder:e,position:t="top-center",toastOptions:a,gutter:r,children:o,containerStyle:s,containerClassName:n})=>{let{toasts:l,handlers:c}=H(a);return i.createElement("div",{style:{position:"fixed",zIndex:9999,top:16,left:16,right:16,bottom:16,pointerEvents:"none",...s},className:n,onMouseEnter:c.startPause,onMouseLeave:c.endPause},l.map(a=>{let s=a.position||t,n=ea(s,c.calculateOffset(a,{reverseOrder:e,gutter:r,defaultPosition:t}));return i.createElement(et,{id:a.id,key:a.id,onHeightUpdate:c.updateHeight,className:a.visible?er:"",style:n},"custom"===a.type?N(a.message,a):o?o(a):i.createElement(ee,{toast:a,position:s}))}))},es=B}},function(e){e.O(0,[972,569,263,971,596,744],function(){return e(e.s=2513)}),_N_E=e.O()}]);