"use client"
import Styles from "./page.module.css"

export default function Page() {
    return (
        <div>
            wishlist
        </div>
    )
}
