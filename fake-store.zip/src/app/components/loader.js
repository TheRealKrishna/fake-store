"use client"
import Styles from "./loader.module.css"
export default function Loader() {
  return (
      <span className={Styles.loader} style={{marginTop: "250px"}}></span>
  )
}
